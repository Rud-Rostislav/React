# Pokedex App
https://rud-rostislav.github.io/React_Pokemon_Cards/

The Pokedex application is built utilizing React.js. The application fetches data from the "PokeAPI" and presents an
interactive Pokedex, which is a digital encyclopedia of Pokemon characteristics.
Key features of the application include:
List of Pokemon: Upon loading the application, users are presented with a list of Pokemon fetched from the API. This
list can be expanded by pressing the "Load more" button, adding 12 more Pokemon to the list each time.
Filter by Type: Users can filter Pokemon by their types using a dropdown menu, which displays all available Pokemon
types.
Pokemon Details: By clicking on a button related to each Pokemon, users can open a detailed view that includes
additional information such as Types, Attack, Defense, HP, SP Attack, SP Defense, Speed, Weight, and Total Moves. This
view can be closed by clicking the same button.
Interactive User Interface: The application provides an interactive user interface, enhancing user experience by showing
Pokemon details on demand and providing a seamless type filtering mechanism.

This project is a simple Pokedex app created with ReactJS. It fetches Pokemon data from the PokeAPI, allows you to see
the characteristics of a specific Pokemon, and filter them by type.

## Getting started

These instructions will get you a copy of the project up and running on your local machine for development and testing
purposes.

### Prerequisites

You need to have `node` and `npm` installed in your system. Node comes with npm pre-installed but you may need to update
it to the latest version. You can check their versions using the following commands in your terminal.

You also need to have ReactJS installed. You can install it using npm with the following command:
npm install -g create-react-app

Installing
After you’ve confirmed that your environment meets the above requirements, you can clone this project and install the
dependencies.
Clone this repository to a directory of your choice.
git clone https://github.com/[username]/[repository]

Navigate to the created directory.
cd [repository]

Next, install the dependencies.
npm install

Running
To run this project you can use the start script command available in the package.json file.
npm start

Your app should now be running on http://localhost:3000.

Upload to GitHub Pages
npm run deploy
