import React, {useState, useEffect, useCallback} from 'react';
import "./style.css"

export default function App() {
    // pokemonData holds an array of the fetched Pokemon from the API.
    const [pokemonData, setPokemonData] = useState([]);

    // page manages the current "page" of the API we're fetching from. It's used for the Pokemon list pagination.
    const [page, setPage] = useState(1);

    // selectedPokemon stores the Pokemon data that is currently selected by the user for displaying detailed info.
    const [selectedPokemon, setSelectedPokemon] = useState(null);

    // availableTypes holds the list of available Pokemon types which are fetched from the API.
    const [availableTypes, setAvailableTypes] = useState([]);

    // selectedType keeps track of the currently selected type in the filter menu. This is used to filter the Pokemon list by type.
    const [selectedType, setSelectedType] = useState('');

    // showDetails indicates if the detailed info of a Pokemon is currently being shown or not.
    const [showDetails, setShowDetails] = useState(false);

    // lastClicked holds the name of the last clicked Pokemon. This is used to reset the detailed view of the last clicked Pokemon when a new one is clicked.
    const [lastClicked, setLastClicked] = useState(null);

    // Load more button state
    const [isLoading, setIsLoading] = useState(false);

    // Constant for number of Pokemon data to be fetched per request
    const limit = 12;

    // State hooks for control whether the Pokemon details are viewed or not
    const [viewDetailState, setViewDetailState] = useState({});

    // Filtering Pokemon data based on the selected type
    const filteredPokemonData = selectedType ? pokemonData.filter((pokemon) => pokemon.types.includes(selectedType)) : pokemonData;

    // Fetching Pokemon data based on the page number
    const fetchData = useCallback(async (page) => {
        setIsLoading(true);
        const offset = limit * (page - 1); // Calculate the offset based on the limit and page

        // Fetch list of Pokemon based on limit and offset
        const response = await fetch(`https://pokeapi.co/api/v2/pokemon/?limit=${limit}&offset=${offset}`);
        const data = await response.json();

        // Fetch individual Pokemon details
        const pokemonDetails = await Promise.all(data.results.map(async (pokemon) => {
            const individualPokemonResponse = await fetch(pokemon.url);
            const individualPokemonData = await individualPokemonResponse.json();

            // Returning combined data for each Pokemon
            return {
                ...pokemon, types: individualPokemonData.types.map((type) => type.type.name),
                sprites: individualPokemonData.sprites,
            };
        }));

        // Updating the state variables with new fetched data
        setPokemonData(prevData => {
            const combinedData = [...prevData, ...pokemonDetails];
            setAvailableTypes([...new Set(combinedData.flatMap(pokemon => pokemon.types))]);
            setIsLoading(false);
            return combinedData;
        });
    }, [limit]);

    // Fetching details of a particular Pokemon
    const fetchPokemonDetails = async (name) => {
        const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${name}`);
        const data = await response.json();
        setSelectedPokemon(data);
        setShowDetails(name);
    }

// Handling clicks on Pokemon
    const handleClick = (name) => {
        // If another button was clicked before, set its viewDetailState to false
        if (lastClicked) {
            setViewDetailState(prevState => ({...prevState, [lastClicked]: false}));
        }
        // If details of the clicked Pokemon are already showing, hide them
        if (showDetails === name) {
            setShowDetails(false);
            setViewDetailState(prevState => ({...prevState, [name]: false}));
        } else {
            // If clicked Pokemon is not showing details, retrieve and show details
            setViewDetailState(prevState => ({...prevState, [name]: true}));
            fetchPokemonDetails(name).catch(error => console.error(error));
        }
        // Update lastClicked with the currently clicked Pokemon
        setLastClicked(name);
    }

    // Fetch Pokemon data once the component mounts and whenever the page changes
    useEffect(() => {
        (async () => {
            try {
                await fetchData(page);
            } catch (error) {
                console.log('Failed to fetch data: ', error);
                setIsLoading(false);
            }
        })();
    }, [page, fetchData]);

    // Mapping Pokemon types to respective background colors
    const typeToColorMap = {
        'grass': '#7fd900',
        'bug': 'rgb(45,84,0)',
        'fire': '#ff1500',
        'ice': '#a3dcff',
        'flying': '#7dd5ff',
        'water': '#008dd5',
        'electric': '#ffcc00',
        'normal': '#ffe887',
        'fairy': '#FF99FF',
        'psychic': '#FF0000',
        'fighting': '#910000',
        'ground': '#884600',
        'dragon': '#833030',
        'poison': '#b300b3',
        'ghost': '#8a2be2',
        'steel': '#C0C0C0',
        'rock': '#797979',
        'dark': '#333333'
    }

    let getColor = (type) => {
        return typeToColorMap[type] ? typeToColorMap[type] : "";
    }


    return (<>
        <div className="center-on-page">
            <div className="pokeball">
                <div className="pokeball__button"></div>
            </div>
        </div>

        <h1>Pokedex</h1>

        <select value={selectedType} onChange={(e) => setSelectedType(e.target.value)}>
            <option value=''>All types</option>
            {availableTypes.map((type, index) => (<option key={index} value={type}>{type}</option>))}
        </select>

        <div className='pokemon_list'>

            {filteredPokemonData.map((poke, index) => (
                <div key={index} className='single_pokemon'>

                    <img src={poke.sprites.front_default} alt={poke.name} className='pokemon_img'/>

                    <p className='poke_name'>{poke.name}</p>

                    <div className='poke_types'>
                        {poke.types && poke.types[0] && <p className='poke_type'
                                                           style={{backgroundColor: getColor(poke.types[0])}}>{poke.types[0]}</p>}
                        {poke.types && poke.types[1] && <p className='poke_type'
                                                           style={{backgroundColor: getColor(poke.types[1])}}>{poke.types[1]}</p>}
                        {poke.types && poke.types[2] && <p className='poke_type'
                                                           style={{backgroundColor: getColor(poke.types[2])}}>{poke.types[2]}</p>}
                    </div>

                    {showDetails === poke.name && selectedPokemon && (
                        <div className="pokemon_detail">

                            <p className='pokemon_detail_name'>{selectedPokemon.id}. {selectedPokemon.name}</p>

                            <table border='1'>
                                <tbody>
                                <tr>
                                    <td>Types</td>
                                    <td className='types_capitalize'>{selectedPokemon.types.map(type => type.type.name).join(', ')}</td>
                                </tr>
                                </tbody>
                                <tbody>
                                <tr>
                                    <td>Attack</td>
                                    <td>{selectedPokemon.stats.find(stat => stat.stat.name === 'attack').base_stat}</td>
                                </tr>
                                </tbody>
                                <tbody>
                                <tr>
                                    <td>Defense</td>
                                    <td>{selectedPokemon.stats.find(stat => stat.stat.name === 'defense').base_stat}</td>
                                </tr>
                                </tbody>
                                <tbody>
                                <tr>
                                    <td>HP</td>
                                    <td>{selectedPokemon.stats.find(stat => stat.stat.name === 'hp').base_stat}</td>
                                </tr>
                                </tbody>
                                <tbody>
                                <tr>
                                    <td>SP Attack</td>
                                    <td>{selectedPokemon.stats.find(stat => stat.stat.name === 'special-attack').base_stat}</td>
                                </tr>
                                </tbody>
                                <tbody>
                                <tr>
                                    <td>SP Defense</td>
                                    <td>{selectedPokemon.stats.find(stat => stat.stat.name === 'special-defense').base_stat}</td>
                                </tr>
                                </tbody>
                                <tbody>
                                <tr>
                                    <td>Speed</td>
                                    <td>{selectedPokemon.stats.find(stat => stat.stat.name === 'speed').base_stat}</td>
                                </tr>
                                </tbody>
                                <tbody>
                                <tr>
                                    <td>Weight</td>
                                    <td>{selectedPokemon.weight}</td>
                                </tr>
                                </tbody>
                                <tbody>
                                <tr>
                                    <td>Total Moves</td>
                                    <td>{selectedPokemon.moves.length}</td>
                                </tr>
                                </tbody>
                            </table>
                        </div>)}

                    <button
                        onClick={() => handleClick(poke.name)}
                        className='view_details'
                        style={viewDetailState[poke.name] ? {backgroundColor: '#960000'} : null}>
                        {viewDetailState[poke.name] ? 'Close' : 'Explore'}
                    </button>

                </div>))}

        </div>

        <button className='load_more' onClick={() => setPage(prevPage => prevPage + 1)} disabled={isLoading}>Load more
        </button>

    </>);
}