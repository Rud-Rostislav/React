import {Dimensions, StyleSheet} from "react-native";

// Отримати розміри екрану
const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;

/**
 * Returns styles based on the provided theme
 * @param isDarkMode {boolean}
 * @return {StyleSheet.NamedStyles<any>}
 */

export const getStyles = (isDarkMode) => StyleSheet.create({
    // Контейнер всього додатку
    appContainer: {
        height: screenHeight,
        paddingVertical: 10,
        alignItems: 'center',
        width: screenWidth,
        backgroundColor: isDarkMode ? '#222325' : '#FFF',
    },

    // Кнопка режимів світла
    darkModeToggle: {
        backgroundColor: '#2c2c2c',
        borderRadius: 10,
        padding: 10,
        width: screenWidth * 0.3,
    },

    // Змінювати колір тексту при зміні теми
    lightDarkModeColorText: {
        color: isDarkMode ? '#FFF' : '#333',
    },

    // Текст кнопки вирівняти по центру
    ButtonTextAlign: {
        textAlign: 'center',
        padding: 5,
        fontSize: 18,
    },

    // Кнопки внизу контейнер
    buttonsContainer: {
        position: 'absolute',
        bottom: 0,
        flexDirection: 'column',
        justifyContent: 'space-between',
        alignItems: 'center',
        width: screenWidth,
        paddingBottom: 25,
        backgroundColor: isDarkMode ? '#222325' : '#FFF',
    },

    // Кнопка додати
    addButton: {
        backgroundColor: '#2c2c2c',
        borderRadius: 10,
        width: screenWidth * 0.3,
    },

    // Кнопка очистити
    deleteButton: {
        backgroundColor: '#9d9d9d',
        borderRadius: 10,
        width: screenWidth * 0.3,
    },

    // Колір тексту для кнопок DarkMode
    buttonText: {
        color: '#FFF',
    },

    // Стиль для кнопок Додати і Очистити
    button: {
        width: screenWidth * 0.3,
        alignItems: 'center',
        padding: 10,
        marginHorizontal: 5,
    },

    // Контейнер кнопки внизу Очистити, додати, режим
    deleteClearButtons: {
        flexDirection: 'row',
        justifyContent: "center",
        marginVertical: 10,
    },

    // Enter your goal input
    textInput: {
        width: screenWidth * 0.95,
        borderWidth: 1,
        borderColor: '#adadad',
        padding: 15,
        textAlign: 'center',
        borderRadius: 50,
        marginBottom: 25,
        backgroundColor: isDarkMode ? '#222325' : '#FFF',
    },

    // Контейнер для списку
    goalsContainer: {
        width: screenWidth,
        alignItems: 'center',
        marginTop: 35,
    },

    // Header списку
    listOfGoalsText: {
        fontSize: 24,
    },

    // Список кожен елемент
    listOfGoals: {
        padding: 20,
        alignItems: 'center',
        borderRadius: 10,
        width: screenWidth * 0.9,
        shadowColor: isDarkMode ? '#606060' : '#1f1f1f',
        shadowOffset: {
            width: 0, height: 3,
        },
        shadowOpacity: 0.3,
        shadowRadius: 2.62,
        elevation: 4,
        borderWidth: 0.5,
        borderColor: isDarkMode ? '#606060' : 'rgba(93,93,93,0.28)',
        marginVertical: 10,
    },

    // Стиль для ScrollView
    scrollView: {
        marginBottom: 120,
    }
});