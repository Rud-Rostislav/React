import {ScrollView, Text, TextInput, TouchableOpacity, View, KeyboardAvoidingView, Platform} from 'react-native';
import {useEffect, useState} from "react";
import {getStyles} from './AppStyles';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function App() {

    // Ініціалізація стану додатку
    useEffect(() => {
        void restoreState();
    }, []);

    // Для відновлення стану
    const restoreState = async () => {
        try {
            const savedGoals = await AsyncStorage.getItem('goals');
            const savedDarkMode = await AsyncStorage.getItem('darkMode');
            if (savedGoals !== null) {
                setGoals(JSON.parse(savedGoals)); // Преобразовуємо строку назад в об'єкт
            }
            if (savedDarkMode !== null) {
                setIsDarkMode(JSON.parse(savedDarkMode)); // Преобразовуємо строку назад в об'єкт
            }
        } catch (error) {
            // Error retrieving data
            console.log(error);
        }
    };

    // Список завдань
    const [goals, setGoals] = useState([]);

    // Поле вводу
    const [input, setInput] = useState('');

    // Перемикач для режиму теми
    const [isDarkMode, setIsDarkMode] = useState(false);

    // Стилі
    const styles = getStyles(isDarkMode);

    // Функція додавання завдання до списку і очищення інпуту
    const addGoalHandler = () => {
        if (input.trim() !== '') {
            const updatedGoals = [...goals, {text: input}];
            setGoals(updatedGoals);
            setInput('');
            void AsyncStorage.setItem('goals', JSON.stringify(updatedGoals));
        }
    };

    // Очистка списку
    const clearGoalHandler = () => {
        setGoals([]);
        void AsyncStorage.setItem('goals', JSON.stringify([]));
    }

    // Зміна темного режиму
    const toggleDarkMode = () => {
        setIsDarkMode(!isDarkMode);
        void AsyncStorage.setItem('darkMode', JSON.stringify(!isDarkMode));
    }

    return (
        <View style={styles.appContainer}>

            <ScrollView contentContainerStyle={{paddingBottom: 100}} style={styles.scrollView}>
                <View style={styles.goalsContainer}>
                    {goals.map((goal, index) =>
                        <TouchableOpacity key={index} style={styles.listOfGoals} onPress={() => {
                            setGoals(currentGoals => currentGoals.filter((_, i) => i !== index));
                        }}>
                            <Text style={styles.lightDarkModeColorText}>{goal.text}</Text>
                        </TouchableOpacity>)
                    }
                </View>
            </ScrollView>

            <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"}
                                  style={styles.buttonsContainer}>
                <Text style={[styles.listOfGoalsText, styles.lightDarkModeColorText]}>
                    {goals.length ? `Кількість справ: ${goals.length}` : "Справ немає"}
                </Text>

                <View style={styles.deleteClearButtons}>

                    <TouchableOpacity style={[styles.button, styles.addButton]} onPress={addGoalHandler}>
                        <Text style={[styles.buttonText, styles.ButtonTextAlign]}>Додати</Text>
                    </TouchableOpacity>

                    <TouchableOpacity style={[styles.button, styles.deleteButton]} onPress={clearGoalHandler}>
                        <Text style={[styles.buttonText, styles.ButtonTextAlign]}>Очистити</Text>
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.darkModeToggle} onPress={toggleDarkMode}>
                        <Text
                            style={[styles.buttonText, styles.ButtonTextAlign]}>{isDarkMode ? "🌙" : "☀️"}</Text>
                    </TouchableOpacity>

                </View>

                <TextInput style={[styles.textInput, styles.lightDarkModeColorText]} placeholder='Введіть задачу'
                           value={input} placeholderTextColor={isDarkMode ? '#FFF' : '#333'}
                           onChangeText={text => setInput(text)}/>
            </KeyboardAvoidingView>

        </View>
    );
}